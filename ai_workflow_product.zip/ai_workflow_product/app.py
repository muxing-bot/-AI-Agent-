import streamlit as st
from agents.pipeline import run_workflow

st.set_page_config(page_title="AI Office Assistant", layout="centered")

st.title("🤖 AI 办公助手（产品级Demo）")

st.markdown("### 输入你的任务")
task = st.text_input("", "写一份本周工作总结")

if st.button("🚀 执行任务"):
    with st.spinner("AI 正在处理任务..."):
        result = run_workflow(task)
    
    st.success("✅ 任务完成！")
    
    st.markdown("### 📄 输出结果")
    st.write(result["result"])
