def summarize(text):
    print("[Summarizer] Summarizing...")

    summary = "【AI总结】\n" + text[:120] + "..."

    return summary
