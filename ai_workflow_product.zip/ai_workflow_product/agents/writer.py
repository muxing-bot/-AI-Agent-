def write(plan):
    print("[Writer] Generating content...")

    task = plan["task"]

    content = f"""
本周工作总结：

1. 完成任务：{task}
2. 推进了相关项目进展
3. 优化了部分流程，提高效率

下周计划：
- 持续推进当前任务
- 提升工作质量
"""

    return content
