def plan(task):
    print("[Planner] Planning task...")
    
    return {
        "task": task,
        "steps": [
            "analyze",
            "generate",
            "summarize"
        ]
    }
