def validate(summary):
    print("[Validator] Checking result...")

    return {
        "status": "ok",
        "result": summary
    }
