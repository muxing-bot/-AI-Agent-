from .planner import plan
from .writer import write
from .summarizer import summarize
from .validator import validate

def run_workflow(task):
    print("[Pipeline] Start")

    p = plan(task)
    w = write(p)
    s = summarize(w)
    v = validate(s)

    print("[Pipeline] Done")

    return v
